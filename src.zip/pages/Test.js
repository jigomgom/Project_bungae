import React, { useRef } from "react";
import { useSelector } from "react-redux/es/exports";

//Components
import SearchCard from "../components/SearchCard";

//CSS
import "../styles/BottomSheet.css";

function Test() {
  // const searchList = useSelector((state) => state.Bungle.moreList);

  const showBottomSheet = () => {
    let container = document.querySelector("#bottomSheetContainer");
    let bottomSheet = document.querySelector(
      "#bottomSheetContainer #bottomSheet"
    );
    container.classList.add("active");
    setTimeout(() => {
      bottomSheet.classList.add("active");
    }, 1);
  };

  const hideBottomSheet = () => {
    let container = document.querySelector("#bottomSheetContainer");
    let bottomSheet = document.querySelector(
      "#bottomSheetContainer #bottomSheet"
    );
    bottomSheet.classList.remove("active");
    setTimeout(() => {
      container.classList.remove("active");
    }, 400);
  };

  return (
    <>
      <div
        id="bottomSheetController"
        onClick={() => {
          showBottomSheet();
        }}
      >
        <div id="bottomSheetControllerHeader"></div>
      </div>
      <div
        id="bottomSheetContainer"
        onClick={() => {
          hideBottomSheet();
        }}
      >
        <div id="bottomSheet">
          <div id="bottomSheetHeader"></div>
          {/* {searchList &&
            searchList.map((item, index) => {
              return <SearchCard key={index} moreList={item} />;
            })} */}
        </div>
      </div>
    </>
  );
}

export default Test;
